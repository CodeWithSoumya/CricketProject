﻿using System.ComponentModel.DataAnnotations;

namespace CricketManagement.Models
{
    public class VenueModel
    {
        [Key]
        public int venueId { get; set; }
        public string? venueName { get; set; }
        public string? venueImageURL { get; set; }
        public string? venueDescription { get; set; }
        public string? VenueLocation { get; set; }
    }
}
