﻿using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;
using VenueManagement.Core;

namespace VenueManagement1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VenueController : ControllerBase
    {
        private readonly IVenue ivenue;
        public VenueController(IVenue ivenue)
        {
            this.ivenue = ivenue;
        }

        [HttpGet]
        [Route("ReadVenue")]
        public IActionResult ReadVenue(int VenueId)
        {
            try
            {
                var response = ivenue.ReadVenue(VenueId);
                return Ok(response);
            }
            catch (System.Exception)
            {
                throw;
            }
        }
        [HttpPost]
        [Route("CreateVenue")]
        public IActionResult CreateVenue(VenueModel venue)
        {
            try
            {
                var response = ivenue.CreateVenue(venue);
                return Ok(response);
            }
            catch (System.Exception)
            {
                throw;
            }
        }



        [HttpPost]
        [Route("UpdateVenue")]
        public IActionResult updateVenue(VenueModel venuemodel,int VenueId)
        {
            try
            {
                var response = ivenue.UpdateVenue(venuemodel,VenueId);
                return Ok(response);
            }
            catch (System.Exception)
            {
                throw;
            }
        }




        [HttpDelete]
        [Route("DeleteVenue")]
        public IActionResult DeleteVenue(int VenueId)
        {
            try
            {
                var response = ivenue.DeleteVenue(VenueId);
                return Ok(response);
            }
            catch (System.Exception)
            {
                throw;
            }
        }
    }
}



