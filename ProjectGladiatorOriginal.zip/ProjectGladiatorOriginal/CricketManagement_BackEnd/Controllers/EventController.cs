﻿using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CricketManagement.Controllers
{
    [ApiController]
    [Route("api/controller")]
    public class EventController : ControllerBase
    {
        private readonly IEvent _ievent;

        public EventController(IEvent ievent)
        {
            this._ievent = ievent;
        }

        [HttpPost]
        [Route("create")]
        public IActionResult CreateEvent(EventModel eventModel)
        {
            try
            {
                var Response = _ievent.CreateEvent(eventModel);
                return Ok(Response);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet]
        [Route("ReadById")]
        public EventModel ReadByEvents(int eventId)
        {
            try
            {
                var Response = _ievent.ReadByEvents(eventId);
                return (Response);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        [Route("Update")]
        public IActionResult UpdateEvent(EventModel eventModel, int eventId)
        {
            try
            {
               
               var Response = _ievent.UpdateEvent(eventModel,eventId);
               return Ok(Response);
                
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteEvent(int eventId)
        {
            try
            {
                var Response = _ievent.DeleteEvent(eventId);
                return Ok(Response);
            }
            catch (Exception)
            {

                throw;
            }
        }


    }
}
