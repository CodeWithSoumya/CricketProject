﻿//using CricketManage_db.Context;


using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CricketManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class TeamController:ControllerBase
    {
        private readonly ITeamCore iteamint;
        private readonly ILogger<TeamController> logger;
        public TeamController(ITeamCore iteamint, ILogger<TeamController> logger)
        {
            this.iteamint = iteamint;
            this.logger = logger;
        }


        [HttpGet]
        [Route("getTeam")]

        public TeamModel readbyid(int id)
        {
            try
            {
                var res = iteamint.readbyid(id);
                return res;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpDelete]
        [Route("deleteTeam/{teamId}")]

        public IActionResult deleteTeam(int teamId)
        {
            try
            {
                var response = iteamint.deleteTeam(teamId);
                return Ok(response);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("addTeam")]

        public IActionResult addTeam(TeamModel teamModel)
        {
            try
            {
                var response = iteamint.addTeam(teamModel);
                return Ok(response);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("editTeam")]

        public IActionResult editTeam(TeamModel team, int teamId)
        {
            try
            {
                var response = iteamint.editTeam(team, teamId);
                return Ok(response);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
