﻿using Microsoft.EntityFrameworkCore;
using CricketManagement.Models;


namespace CricketManagement.Context
{
    public class CricketContext : DbContext
    {
        public CricketContext(DbContextOptions<CricketContext> options) : base(options) 
        { }
        public DbSet<AdminModel> adminModels { get; set; }
        public DbSet<UserModel> userModels { get; set; }
        public DbSet<LoginModel> loginModels { get; set; }
        public DbSet<EventModel> EventTable { get; set; }
        public DbSet<VenueModel> Venuetable { get; set; }
        public DbSet<TeamModel> teamModels { get; set; }
        public DbSet<RefereeModels> refereemodel { get; set; }

    }
}
