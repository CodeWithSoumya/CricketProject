﻿using CricketManagement.Models;


namespace yogatraininghiringsystemproject.Core.Interface
{
    public interface IAuth 
    {
        Task<ResponseModel> RegisterUser(UserModel userModel);
        ResponseModel GenerateToken(LoginModel loginModel);
    }
}
