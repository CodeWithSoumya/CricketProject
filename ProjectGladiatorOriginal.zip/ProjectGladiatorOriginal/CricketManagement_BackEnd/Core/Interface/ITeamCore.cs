﻿
using CricketManagement.Models;

namespace CricketManagement.Core.Interface
{
    public interface ITeamCore
    {
        // Task<ResponseModel> addTeam(TeamModel teamModel);
        //IEnumerable<TeamModel> ReadAllTeam();


        TeamModel readbyid(int teamId);
        string addTeam(TeamModel teamModel);
        string editTeam(TeamModel team, int teamId);
        string deleteTeam(int teamId);
    }
}
