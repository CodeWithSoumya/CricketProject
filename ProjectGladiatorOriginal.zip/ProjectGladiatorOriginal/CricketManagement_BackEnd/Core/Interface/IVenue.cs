﻿using CricketManagement.Models;


namespace CricketManagement.Core.Interface
{
    public interface IVenue
    {
         string CreateVenue(VenueModel venueModel);
        VenueModel ReadVenue(int VenueId);
        string UpdateVenue(VenueModel venuemodel,int VenueId);
        string DeleteVenue(int VenueId);

        
    }
}
