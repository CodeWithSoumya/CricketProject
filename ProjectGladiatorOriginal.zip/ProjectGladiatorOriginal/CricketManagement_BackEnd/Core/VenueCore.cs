﻿using System.Collections.Generic;
using System;
using System.Linq;
using CricketManagement.Context;
using CricketManagement.Models;
using CricketManagement.Core.Interface;

namespace VenueManagement.Core
{
    public class Venue : IVenue
    {
        private readonly CricketContext venueContext;
        public Venue(CricketContext VenueContext)
        {
            this.venueContext = VenueContext;

        }

        public string CreateVenue(VenueModel venue)
        {
            try
            {
                venueContext.Add(venue);
                venueContext.SaveChanges();
                return $"Created Successfully";
            }
            catch (Exception)
            {
                throw;
            }
            throw new NotImplementedException();
        }


        public string DeleteVenue(int id)
        {
            try
            {
                var venue = venueContext.Venuetable.Find(id);
                if (venue != null)
                {
                    venueContext.Remove(venue);
                    venueContext.SaveChanges();
                    return $"Removed Venue{venue.venueName}";
                }
                return $"There is nothing matchable for your id {id}";
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEnumerable<VenueModel> Read()
        {
            try
            {
                return venueContext.Venuetable.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public VenueModel ReadVenue(int VenueId)
        {
            try
            {
                var a = venueContext.Venuetable.Find(VenueId);
                venueContext.SaveChanges();
                return a;


            }
            catch (Exception)
            {

                throw;
            }
        }

        public string UpdateVenue(VenueModel venuemodel, int venueid)
        {
            try
            {
                var venue = venueContext.Venuetable.Find(venueid);

                if (venue != null)
                {
                    venue.venueName = venuemodel.venueName;
                    venue.venueImageURL = venuemodel.venueImageURL;
                    venue.venueDescription = venuemodel.venueDescription;
                    venue.VenueLocation = venuemodel.VenueLocation;
                    venueContext.Venuetable.Update(venue);
                    venueContext.SaveChanges();
                    return "Update is create";
                }
                else
                {
                    return "Show some exception Error";
                }
            }
            catch (System.Exception)
            {
                throw;
            }
        }

    }
}








